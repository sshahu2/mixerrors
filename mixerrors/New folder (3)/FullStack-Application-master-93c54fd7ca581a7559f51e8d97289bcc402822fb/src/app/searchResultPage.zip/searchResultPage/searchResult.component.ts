import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  ElementRef
} from "@angular/core";

import { GraphService } from "../services/graph.service";
import { DataService } from "../services/data.service";
import { CustomizationDialogComponent } from "../customization-dialog/customization-dialog.component";
import { VERSION, MatDialog, MatDialogRef } from "@angular/material";
import { StocksService } from "../stock-price/stocks.service";
import { MatTableDataSource } from "@angular/material";
import { Element } from "../model/element";
import { GraphDialogComponent } from "../graph-dialog/graph-dialog.component";

@Component({
  selector: "app-searchresult",
  templateUrl: "./searchResult.component.html",
  styleUrls: ["./searchResult.component.css"]
})
export class SearchresultComponent implements OnInit, AfterViewInit {
  @ViewChild("compareBarChart") compareBarChart: ElementRef;
  @ViewChild("predictedDetailChart") predictedDetailChart: ElementRef;
  @ViewChild("sbuDetailActualChart") doughnut: ElementRef;
  @ViewChild("verDetailActualChart") verBarChart: ElementRef;
  @ViewChild("accDetailActualChart") accBarChart: ElementRef;
  @ViewChild("accTimeLineDetailChart") accTimeLineChart: ElementRef;

  nlpResult: any;
  options: any;

  compareBarElement: any;
  predictedDetailElement: any;
  sbuDetailActualElement: any;
  verDetailActualElement: any;
  accDetailActualElement: any;
  accTimeLineDetailElement: any;

  apiData: any;
  compareBarChartdata: any;
  sbuDetailActualData: any;
  verDetailActualdata: any;
  accDetailActualdata: any;
  accTimeLineDetaildata: any;
  predictedDetailChartdata: any;
  predictedDetailTabledata: any;
  predictedTableHeader: any;

  showCompareTimeChart = false;
  showPredictedDetailChart = false;
  showSbuChart = false;
  showVerChart = false;
  showAccChart = false;
  showTimeLineChart = false;

  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.getNlpResult();
  }

  ngAfterViewInit() {
    try {
      this.sbuDetailActualElement = this.doughnut.nativeElement;
      this.verDetailActualElement = this.verBarChart.nativeElement;
      this.accDetailActualElement = this.accBarChart.nativeElement;
      this.accTimeLineDetailElement = this.accTimeLineChart.nativeElement;
      this.compareBarElement = this.compareBarChart.nativeElement;
      this.predictedDetailElement = this.predictedDetailChart.nativeElement;
    } catch (error) {}
  }

  getNlpResult() {
    this.dataService.getSearchQuery().subscribe(query => {
      this.showCompareTimeChart = false;
      this.showPredictedDetailChart = false;
      this.dataService.destructureQuery(query).subscribe(nlpResult => {
        this.nlpResult = nlpResult;
        const intent = nlpResult['intent'];
        this.dataService.getApiData(nlpResult).subscribe(data => {
          this.apiData = data;
          if (intent === 'revenueCompare') {
            this.createCompareChart(nlpResult, data);
            this.showCompareTimeChart = true;
          } else if (intent === 'revenueDetails') {
            if (nlpResult['revenueState'] === 'actual') {
              this.createActualDetailChart(nlpResult, data);
            } else if (nlpResult['revenueState'] === 'predicted') {
              this.createPredictedDetailChart(nlpResult, data);
            }
            this.showPredictedDetailChart = true;
          }
        });
      });
    });
  }

  createPredictedDetailChart(nlpResult, data) {
    if (nlpResult.sbu === 'allSbu') {
      this.createPredictedOverAllChart(nlpResult, data);
    } else if (nlpResult.sbu) {
      this.createPredictedDetailChart(nlpResult, data);
    }
  }

  createPredictedOverAllChart(nlpResult, apiData) {
    let labels = [];
    let data = [];
    for (let d of apiData) {
      labels.push(d.SBU);
      data.push(d.SBU_PREDICTION);
    }
    this.predictedDetailChartdata = {
      labels: labels,
      datasets: [
        {
          data: data,
          backgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56",
            "#00a950",
            "#58595b",
            "#8549ba"
          ],
          hoverBackgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56",
            "#00a950",
            "#58595b",
            "#8549ba"
          ]
        }
      ]
    };
    this.predictedTableHeader = Object.keys(apiData[0]);
  }

  createPredictedSbuChart(nlpResult, data) {

  }


  createActualDetailChart(nlpResult, data) {
    if (nlpResult.sbu === "allSbu") {
      this.createSbuActualDetail(nlpResult, data);
    } else if (nlpResult.sbu) {
      let selectedSbu = nlpResult.sbu;
      this.createVerActualDetail(nlpResult, selectedSbu, data);
    } else if (nlpResult.vertical) {
      let selectedVer = nlpResult.vertical;
      this.createAccActualDetail(nlpResult, selectedVer, data);
    } else if (nlpResult.account) {
      let selectedAcc = nlpResult.account;
      this.createAccTimeLineActualDetail(nlpResult, selectedAcc, data);
    }
  }

  createSbuActualDetail(nlpResult, apiData) {
    let labels = [];
    let data = [];
    for (let d of apiData) {
      labels.push(d.sbu);
      data.push(d.SBU_REVENUE);
    }
    this.sbuDetailActualData = {
      labels: labels,
      datasets: [
        {
          data: data,
          backgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56",
            "#00a950",
            "#58595b",
            "#8549ba"
          ],
          hoverBackgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56",
            "#00a950",
            "#58595b",
            "#8549ba"
          ]
        }
      ]
    };
    this.options = {
      responsive: false,
      legend: {
        position: "top"
      },
      title: {
        display: true,
        text: "Wipro's Overall Analysis"
      },
      animation: {
        animateScale: true,
        animateRotate: true
      }
    };
  }

  selectPie(event) {
    let selectedSbu = this.sbuDetailActualData.labels[event.element._index];
    this.createVerActualDetail(this.nlpResult, selectedSbu, this.apiData);
  }

  getAccounts(event) {
    let selectedVer = this.verDetailActualdata.labels[event.element._index];
    this.createAccActualDetail(this.nlpResult, selectedVer, this.apiData);
  }

  getLineChart(event) {
    let selectedAcc = this.accDetailActualdata.labels[event.element._index];
    this.createAccTimeLineActualDetail(this.nlpResult, selectedAcc, this.apiData);
  }

  createVerActualDetail(nlpResult, selectedSbu, apiData) {
    let labels = [];
    let data = [];
    apiData.sort(function(a, b) {
      return b.VERTICAL_REVENUE - a.VERTICAL_REVENUE;
    });
    for (let d of apiData) {
      if (selectedSbu.toLowerCase() === d.sbu.toLowerCase()) {
        labels.push(d.VERTICAL);
        data.push(d.VERTICAL_REVENUE);
      }
    }
    this.verDetailActualdata = {
      labels: labels,
      datasets: [
        {
          label: selectedSbu + "'s verticals",
          backgroundColor: this.getRandomColor(),
          borderColor: this.getRandomColor(),
          data: data
        }
      ]
    };
    try {
      this.verDetailActualElement.refresh();
    } catch (error) { }
  }

  createAccActualDetail(nlpResult, selectedVer, apiData) {
    let labels = [];
    let data = [];
    apiData.sort(function(a, b) {
      return b.ACCOUNT_REVENUE - a.ACCOUNT_REVENUE;
    });
    for (let d of apiData) {
      if (selectedVer.toLowerCase() === d.vertical.toLowerCase()) {
        labels.push(d.ACCOUNT);
        data.push(d.ACCOUNT_REVENUE);
      }
    }
    this.verDetailActualdata = {
      labels: labels,
      datasets: [
        {
          label: selectedVer + "'s verticals",
          backgroundColor: this.getRandomColor(),
          borderColor: this.getRandomColor(),
          data: data
        }
      ]
    };
    try {
      this.accDetailActualElement.refresh();
    } catch (error) { }
  }

  createAccTimeLineActualDetail(nlpResult, selectedAcc, apiData) {
    let labels = [];
    let data = [];
    for (let t of apiData) {
      if (t.account.toLowerCase() === selectedAcc.toLowerCase()) {
        labels.push(t.category);
        data.push(t.measure);
      }
    }
    if (labels.length > 0) {
      this.showTimeLineChart = true;
    }
    this.accTimeLineDetaildata = {
      labels: labels,
      datasets: [
        {
          label: selectedAcc + "'s Timeline Data",
          data: data,
          fill: false,
          borderColor: this.getRandomColor()
        }
      ],
      options: {
        scales: {
          yAxes: [
            {
              display: true,
              ticks: {
                beginAtZero: true
              }
            }
          ]
        }
      }
    };
    try {
      this.accTimeLineDetailElement.refresh();
    } catch (error) { }
  }

  createCompareChart(nlpResult, data) {
    if (nlpResult.timeline.length >= 0) {
      if (nlpResult.account && nlpResult.account.length >= 1) {
        this.compareAccounts(nlpResult, data);
      } else if (nlpResult.vertical && nlpResult.vertical.length >= 1) {
        this.compareVerticals(nlpResult, data);
      } else if (nlpResult.sbu && nlpResult.sbu.length >= 1) {
        this.compareSbus(nlpResult, data);
      }
    }
  }

  compareAccounts(nlpResult, data) {
    let labels = nlpResult.timeline;
    let accounts = nlpResult.account;
    let compareData = { labels: labels, datasets: [] };
    for (let account of accounts) {
      let tlData = [];
      for (let q of labels) {
        data.map(d => {
          if (d.account.toLowerCase() === account.toLowerCase()) {
            tlData.push(d["" + q]);
          }
        });
      }
      compareData.datasets.push({
        label: account,
        backgroundColor: this.getRandomColor(),
        borderColor: this.getRandomColor(),
        data: tlData
      });
      console.log(compareData.datasets);
      this.compareBarChartdata = compareData;
      this.showCompareTimeChart = true;
    }
  }

  compareVerticals(nlpResult, data) {
    let labels = nlpResult.timeline;
    let verticals = nlpResult.vertical;
    let compareData = { labels: labels, datasets: [] };
    for (let vertical of verticals) {
      let tlData = [];
      for (let q of labels) {
        data.map(d => {
          if (d.group.toLowerCase() === vertical.toLowerCase()) {
            tlData.push(d["" + q]);
          }
        });
      }
      compareData.datasets.push({
        label: vertical,
        backgroundColor: this.getRandomColor(),
        borderColor: this.getRandomColor(),
        data: tlData
      });
      console.log(compareData.datasets);
      this.compareBarChartdata = compareData;
      this.showCompareTimeChart = true;
    }
  }

  compareSbus(nlpResult, data) {
    let labels = nlpResult.timeline;
    let sbus = nlpResult.sbu;
    let compareData = { labels: labels, datasets: [] };
    for (let sbu of sbus) {
      let tlData = [];
      for (let q of labels) {
        data.map(d => {
          if (d.group.toLowerCase() === sbu.toLowerCase()) {
            tlData.push(d["" + q]);
          }
        });
      }
      compareData.datasets.push({
        label: sbu.toUpperCase(),
        backgroundColor: this.getRandomColor(),
        borderColor: this.getRandomColor(),
        data: tlData
      });
      console.log(compareData.datasets);
      this.compareBarChartdata = compareData;
      this.showCompareTimeChart = true;
    }
  }

  getRandomColor() {
    const letters = "0123456789ABCDEF";
    let color = "#";
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
}
